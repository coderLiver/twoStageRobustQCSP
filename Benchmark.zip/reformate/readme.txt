All the other txt files denote the processing times of ship bays.
The followings are one example of processing time for 10 ship bays. 
[0.0,87.0,62.0,0.0,3.0,37.0,58.0,0.0,0.0,19.0] // 